﻿- Entrez le nom de la note dans la case "Filtre". Conseil : mettez bien des mots que vous utiliserez pour la rechercher.
- Pour le reste j'espère que l'interface le rend évident ;)