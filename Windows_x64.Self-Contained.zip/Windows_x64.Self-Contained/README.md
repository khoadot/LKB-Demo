# Le Knowledge Base (alias LKB)

## Présentation

Le Knowledge Base, ou LKB, est une application **portable** de prise et de recherche de notes, faite avec amour (et sueur !).  
Depuis très longtemps jusqu'à 2021, j'ai tâtonné, tâtonné et tâtonné jusqu'à enfin arriver à une méthode de gestion de la connaissance qui me satisfasse vraiment. Cette méthode manquait de l'outil parfaitement adéquat, et c'est ce qui a donné naissance à LKB.  
J'espère que vous en trouverez bon usage à votre tour, peut-être même au point de l'intégrer entièrement à vos flux de travail personnels et/ou professionnels.  

## Installation

Je rappelle que l'application est portable donc c'est plus un démarrage qu'une installation ;).

### Windows

- Récupérez le dossier `Windows_x64_Self-Contained` et mettez-le où bon vous semble. Il contient toute l'application à l'exception des notes en elles-mêmes.
- Démarrez `LeKnowledgeBase_CrossPlatform` (c'est-à-dire `LeKnowledgeBase_CrossPlatform.exe` si vous affichez les extensions de fichier, ce que je conseille), qui est le fichier avec le petit logo.
- Vous pouvez l'utiliser immédiatement, ou bien modifier dès à présent le fichier de configuration `LeKnowledgeBase_CrossPlatform.dll.config` pour changer le dossier cible de notes (plus d'explications dans la suite de ce document). Si c'est le cas, appuyer sur le bouton rafraîchir pour prendre en compte la modification.

### Linux

- Récupérez le dossier `Linux_x64_Self-Contained` et mettez-le où bon vous semble. Il contient toute l'application à l'exception des notes en elles-mêmes.
- Démarrez `LeKnowledgeBase_CrossPlatform`.
- Vous pouvez l'utiliser immédiatement, ou bien modifier dès à présent le fichier de configuration `LeKnowledgeBase_CrossPlatform.dll.config` pour changer le dossier cible de notes (plus d'explications dans la suite de ce document). Si c'est le cas, appuyer sur le bouton rafraîchir pour prendre en compte la modification.

## Mise à jour

Remplacez tous les fichiers du dossier des exécutables par ceux du dossier de la dernière version que vous aurez téléchargée, tout en conservant :
- Votre dossier de notes
- `LeKnowledgeBase_CrossPlatform.dll.config` actuel (pour ne pas avoir à recommencer la config)

## Aspects techniques à comprendre

- Une note textuelle <=> un fichier Markdown (.md) à la racine du dossier. Un fichier .md est fondamentalement un fichier texte. En savoir plus sur le Markdown peut permettre d'optimiser votre expérience, mais n'est pas indispensable.
- L'application n'est qu'une interface qui permet d'interagir avec vos notes qui sont donc de simples fichiers texte. Si l'appli casse ou disparaît, vous ne devriez pas perdre vos notes.
- Ces fichiers textes sont sur votre ordi et l'appli ne les enverra jamais à l'extérieur.

## Suggestions d'utilisation

- Ayez votre dossier de notes **à l'extérieur** du dossier contenant les exécutables.
- Nommez vos notes en vous demandant par quels termes vous la chercherez lorsque vous en aurez besoin dans 1 an.
- "Backuppez" vos notes par un moyen extérieur, par une solution de type cloud par exemple. Personnellement j'utilise git et gitlab.
- Si vous n'avez pas le temps de bien choisir vos mots au moment de la prise de note, ajoutez au nom de la note un tag (par ex "[mal nommé]), et vous la renommerez plus tard pour bien choisir vos mots.
- Informez-vous sur le Markdown et essayez de l'utiliser dans votre vie bureautique dès que c'est pertinent.

## Questions et réponses

***Le dossier peut-il contenir d'autres choses que des notes ?***  
=> Oui, si vous le voulez, notamment c'est utile pour contenir un dossier .git ;)

## Toutes les fonctionnalités

### Recherche rapide
- `Ctrl`+`F` : Met la focalisation sur la barre de filtre (et préselectionne tout le texte)
- `Alt`+`F` : Idem 

### Copie rapide
- Faire clic-droit sur une cellule copie son contenu dans le presse-papier  
- `Alt`+`J` : Copie le contenu de la première note de la grille dans le presse-papier  
- `Alt`+`K` : Copie le contenu de la deuxième note de la grille dans le presse-papier  
- `Alt`+`L` : Copie le contenu de la troisième note de la grille dans le presse-papier  
- `Alt`+`M` : Copie le contenu de la quatrième note de la grille dans le presse-papier  

### Édition rapide
- `Ctrl`+`J` : Démarre l'édition de la première note de la grille  
- `Ctrl`+`K` : Démarre l'édition de la deuxième note de la grille  
- `Ctrl`+`L` : Démarre l'édition de la troisième note de la grille  
- `Ctrl`+`M` : Démarre l'édition de la quatrième note de la grille  
- `Ctrl`+`Maj`+`J` : Démarre le renommage de la première note de la grille  
- `Ctrl`+`Maj`+`K` : Démarre le renommage de la deuxième note de la grille  
- `Ctrl`+`Maj`+`L` : Démarre le renommage de la troisième note de la grille  
- `Ctrl`+`Maj`+`M` : Démarre le renommage de la quatrième note de la grille  
- `Ctrl`+`S` : Enregistre l'édition en cours sans perdre la main sur l'édition (pour le Contenu seulement ; pour les mots-clés il y a perte de la main pour - rester cohérent avec le cas où la note doit disparaître de la grille suite au renommage)  
- `Ctrl`+`T` (pendant l'édition d'une case contenu) : supprime l'espace blanc en début de ligne commun à toutes les lignes  
- `Ctrl`+`Entrée` : Enregistre l'édition en cours en quittant l'édition  
- `Ctrl`+`Entrée` : Crée la note en cours de création  
- `Alt`+`Haut` : Échange la ligne courante avec la ligne au-dessus  
- `Alt`+`Down` : Échange la ligne courante avec la ligne en-dessous  

### Configuration
- Le seul et unique fichier de configuration est `LeKnowledgeBase_CrossPlatform.dll.config`, qui est à côté de `LeKnowledgeBase_CrossPlatform.exe`. Vous pouvez y changer les valeurs de certaines clés décrites ci-après.
- `pathRootFolderNotes` : indique le chemin (relatif ou absolu) du dossier comprenant toutes vos notes. L'application en créera un par défaut mais vous pouvez le changer.
- `windowTitle` : Définit le titre de la fenêtre dans la barre de titre et la barre des tâches.
- `synonymsFilePath` : indique le chemin du fichier qui définit vos synonymes (voir la section sur la fonctionnalité de synonymie). L'application en fixe (un chemin et un fichier) par défaut mais vous pouvez les changer.
- `keyWords_FontSize` : taille de police de la colonne `Mots-Clés` de la grille (supprimez la clé entièrement pour laisser l'application (re)mettre la valeur par défaut)
- `content_FontSize` : taille de police de la colonne `Contenu` de la grille (supprimez la clé entièrement pour laisser l'application (re)mettre la valeur par défaut)
- `encodingWanted` : Si par malheur vous devez utiliser des notes encodées en Windows 1252, indiquez "windows 1252".
- `executeFile_OpenNoteWithDefaultApp`, `executeFile_Arguments`, `executeFile_UseShellExecute`, `executeFile_FileName` : cf. chapitre dédié "Boutons personnalisables"

### Boutons de tout en haut
- Épingle : Bascule la fenêtre en mode "toujours tout au-dessus" (sous-entendu des autres fenêtres)
- Engrenage : Ouvre le fichier de configuration `LeKnowledgeBase_CrossPlatform.dll.config` (sélectionner un éditeur de texte au besoin)  
- Dossier : Ouvre le dossier contenant les notes  
- I : Ouvre le README.md
- Point de géolocalisation : Ouvre le dossier contenant les exécutables de l'application

### Synonymie (à la recherche)
Vous pouvez configurer une liste de groupes de synonymes dans un fichier texte. Cela permet de chercher un terme avec un de ses synonymes à la place.  
Le chemin du fichier text est défini dans la valeur de `synonymsFilePath` dans le fichier de configuration  
Normalement, les modifications faites au fichier de synonymes sont immédiatement prises en compte.

### Cacher des notes dans la grille
Ajouter `[hidden]` dans le nom d'une note la rend invisible dans la grille sauf si vous entrez entièrement `[hidden]` dans la barre de filtre  

### Notes sous forme d'image
Les notes sous forme d'image (png, jpg, bmp) peuvent être affichées et renommées, mais ne peuvente être ajoutées par LKB, elles doivent être ajoutées au dossier des notes par d'autres moyens.  

### Les boutons personnalisables (éclair et œil)

Par défaut, ces boutons ouvrent la note sous forme de fichier avec l'application par défaut configurée dans votre système d'exploitation.  

#### Le bouton "éclair" jaune

***Tableau des valeurs des clés de configuration :***

_Ce tableau s'affiche correctement ssi le markdown est compilé._

| Mode voulu du bouton :arrow_right: <br/> × <br/>Nom de la clé  :arrow_down: | Le bouton ouvre la note avec l'application par défaut¹ | Le bouton exécute l'équivalent de `monApp.exe nom_de_la_note.md` | Le bouton exécute l'équivalent de `monApp.exe --option1 nom_de_la_note.md` | Le bouton exécute l'équivalent de `monScript.sh nom_de_la_note.md` où `monScript.sh` est lui-même exécuté par l'application par défaut¹ | Le bouton exécute l'équivalent de `monScript.sh --option1 nom_de_la_note.md` où `monScript.sh` est lui-même exécuté par l'application par défaut¹ |
|---|---|---|---|---|---|
| `executeFile_OpenNoteWithDefaultApp` | `"True"` | `"False"` | `"False"`| `"False"`| `"False"` |
| `executeFile_FileName` |*Ignoré, peut même être supprimé* | `"chemin/vers/monApp.exe"` | `"chemin/vers/monApp.exe"` | `"chemin/vers/monScript.sh"` |  `"chemin/vers/monScript.sh"` |
| `executeFile_UseShellExecute` | *Ignoré, peut même être supprimé*  | `"False"` | `"False"` | `"True"` | `"True"` |
| `executeFile_Arguments` |*Ignoré, peut même être supprimé* | `""` | `"--option1"` | "" | `"--option1"` |

¹ : *par défaut définie au niveau du système d'exploitation (c'est-à-dire celle utilisée lorsque vous double-cliquez la note dans l'explorateur de fichiers)*

#### Le bouton "œil" bleu

Idem avec le suffixe `2` (`executeFile_OpenNoteWithDefaultApp2`, `executeFile_FileName2`, `executeFile_UseShellExecute2`, `executeFile_Arguments2`)
