﻿Faire clic-droit sur une cellule copie son contenu
Alt+J : Copie le contenu de la première de la grille dans le presse-papier
Alt+K : Copie le contenu de la deuxième de la grille dans le presse-papier
Alt+L : Copie le contenu de la troisième de la grille dans le presse-papier
Alt+M : Copie le contenu de la quatrième de la grille dans le presse-papier

Ctrl+J : Démarre l'édition de la première note de la grille
Ctrl+K : Démarre l'édition de la deuxième note de la grille
Ctrl+L : Démarre l'édition de la troisième note de la grille
Ctrl+M : Démarre l'édition de la quatrième note de la grille