﻿# File ~/.local/share/applications/LKB.desktop
[Desktop Entry]
Name=LKB
GenericName=LeKnowledgeBase
Icon=path/to/bird_1f426.png
Type=Application
Exec=path/to/Linux_x64_Self-Contained/LeKnowledgeBase_CrossPlatform
Keywords=lkb le knowledge base;
